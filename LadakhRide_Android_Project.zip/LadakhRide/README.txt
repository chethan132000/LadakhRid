LADAKH RIDE - Android app project

BUILD THE APK (about 10 minutes, one time)
1. Install Android Studio (free): developer.android.com/studio
2. Unzip this folder. In Android Studio choose File > Open and select the LadakhRide folder.
3. Wait for "Gradle sync" to finish (needs internet the first time).
4. Menu: Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk
6. Copy it to your phone, open it, and allow "install from this source" when asked.

EDIT THE APP CONTENT
All screens, places, history text and dates live in one file:
  app/src/main/assets/index.html
Edit it (places list is the PL array, days are the D array), then rebuild the APK.

PHOTOS
Inside the app, open Places, choose a place, and tap the file box to add photos from
your gallery or camera. They are stored on your phone.

NOTE
Trip dates: change the start date on the Plan screen and every day updates.
